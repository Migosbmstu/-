﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp20
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {

            double m, L, Vm, a,alpha, n = 0.01, nu = 0.05, g = 9.81;
            m = double.Parse(textBox6.Text);
            L = double.Parse(textBox7.Text);
            Vm = double.Parse(textBox8.Text);
            a = double.Parse(textBox9.Text); 
            alpha = double.Parse(textBox10.Text);
            this.chart2.Series[0].Points.Clear();
            this.chart3.Series[0].Points.Clear();
            this.chart4.Series[0].Points.Clear();
            Skor(ref a, ref n);
            Put(ref Vm, ref a, ref L);
            Sila(ref m, ref a, ref n, ref nu, ref g,ref alpha);
        }
        public void Skor(ref double a, ref double n)
        {
            double v = 0, s = 0;
            for (double i = 0; i < 2; i += 0.01) 
            { 
                this.chart2.Series[0].Points.AddXY(i, v);
                v = v + a * n;
            }
            for (double i = 2; i < 3; i += 0.01)
            {
                this.chart2.Series[0].Points.AddXY(i, v);
            }
            for (double i = 3; i < 5; i += 0.01) 
            {
                this.chart2.Series[0].Points.AddXY(i, v);
                v = v - a * n;
            }
            for (double i = 5; i < 6; i += 0.01) 
            {
                v = 0;
                this.chart2.Series[0].Points.AddXY(i, v);
            }
            for (double i = 6; i < 8; i += 0.01) 
            {
                this.chart2.Series[0].Points.AddXY(i, v);
                v = v - a * n;
            }
            for (double i = 8; i < 9; i += 0.01)
            {
                this.chart2.Series[0].Points.AddXY(i, v);
            }
            for (double i = 9; i < 11; i += 0.01)
            {
                this.chart2.Series[0].Points.AddXY(i, v);
                v = v + a * n;
            }
        }
        public void Put(ref double Vm, ref double a,ref double L)
        {
            double t1, t2, t3, t4, t5, t6, t7; 
            double s1, s2, s3, s4, s5, s6, s7;
            t1 = Vm / a; t3 = t1; t5 = t1; t7 = t1;
            t2 = (L / Vm);
            s1 = 0;
            t4 = 1;
            for (double i = 0; i < 2; i += 0.01)
            {
                this.chart3.Series[0].Points.AddXY(i, s1);
                s1 += 0 * t1 + (a * t1 * t1 / 2);
            }
            for (double i = 2; i < 3; i += 0.01)
            {
                this.chart3.Series[0].Points.AddXY(i, s1);
                s1 += Vm * t2;
            }
            for (double i = 3; i < 5; i += 0.01)
            {
                this.chart3.Series[0].Points.AddXY(i, s1);
                s1 += Vm * t3 - (a * t3 * t3 / 2);
            }
            for (double i = 5; i < 6; i += 0.01)
            {
                this.chart3.Series[0].Points.AddXY(i, s1);
            }
            
            for (double i = 6; i < 8; i += 0.01)
            {
                this.chart3.Series[0].Points.AddXY(i, s1);
                s1 += -((0 * t5 + (a * t5 * t5 / 2)));
            }
            for (double i = 8; i < 9; i += 0.01)
            {
                this.chart3.Series[0].Points.AddXY(i, s1);
                s1 += -Vm * t2;
            }
            for (double i = 9; i < 11; i += 0.01)
            {
                this.chart3.Series[0].Points.AddXY(i, s1);
                s1 -= 0 * t1 + (a * t1 * t1 / 2);
            }
        }
        public void Sila(ref double m, ref double a, ref double n, ref double nu, ref double g, ref double alpha)
        {
            double f1, f2, f3, f4, f5, f6, f7;
            f1 = m * g*Math.Sin(alpha*Math.PI/180) + nu * m * g*Math.Cos(alpha * Math.PI / 180)+m*a;
            f2 = m * g * Math.Sin(alpha * Math.PI / 180) + nu * m * g * Math.Cos(alpha * Math.PI / 180);
            f3 = m * g * Math.Sin(alpha * Math.PI / 180) + nu * m * g * Math.Cos(alpha * Math.PI / 180)-m*a;
            f4 = m * g * Math.Sin(alpha * Math.PI / 180) - nu * m * g * Math.Cos(alpha * Math.PI / 180);
            f5 = m * g * Math.Sin(alpha * Math.PI / 180) - nu * m * g * Math.Cos(alpha * Math.PI / 180)-m*a;
            f6 = m * g * Math.Sin(alpha * Math.PI / 180) - nu * m * g * Math.Cos(alpha * Math.PI / 180);
            f7 = m * g * Math.Sin(alpha * Math.PI / 180) - nu * m * g * Math.Cos(alpha * Math.PI / 180) + m * a;
            
            for (double i = 0; i < 2; i += 0.01)
            {
                this.chart4.Series[0].Points.AddXY(i, f1);
            }
            for (double i = 2; i < 3; i += 0.01)
            {
                this.chart4.Series[0].Points.AddXY(i, f2);
            }
            for (double i = 3; i < 5; i += 0.01)
            {
                this.chart4.Series[0].Points.AddXY(i, f3);
            }
            for (double i = 5; i < 6; i += 0.01)
            {
                this.chart4.Series[0].Points.AddXY(i, f4);
            }
            for (double i = 6; i < 8; i += 0.01)
            {
                this.chart4.Series[0].Points.AddXY(i, f5);
            }
            for (double i = 8; i < 9; i += 0.01)
            {
                this.chart4.Series[0].Points.AddXY(i, f6);
            }
            for (double i = 9; i < 11; i += 0.01)
            {
                this.chart4.Series[0].Points.AddXY(i, f7);
            }
            label6.Text = $"Fmax = {Math.Round(f1,2)}Н";
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog sfd = new SaveFileDialog()) // использование метода SaveFileDialog для сохранения изображений графиков на ПК
            {
                sfd.Filter = "*.png|*.png;|*.jpg|*.jpg"; // выбор формата файла сохранения
                sfd.AddExtension = true;
                sfd.FileName = "Скорость";
                if (sfd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    switch (sfd.FilterIndex)
                    {
                        case 1: chart2.SaveImage(sfd.FileName, System.Windows.Forms.DataVisualization.Charting.ChartImageFormat.Png); break; // сохранение в формате png
                        case 2: chart2.SaveImage(sfd.FileName, System.Windows.Forms.DataVisualization.Charting.ChartImageFormat.Jpeg); break; //сохранение в формате jpeg
                    }
                }
            }
            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "*.png|*.png;|*.jpg|*.jpg";
                sfd.AddExtension = true;
                sfd.FileName = "Путь";
                if (sfd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    switch (sfd.FilterIndex)
                    {
                        case 1: chart2.SaveImage(sfd.FileName, System.Windows.Forms.DataVisualization.Charting.ChartImageFormat.Png); break; 
                        case 2: chart2.SaveImage(sfd.FileName, System.Windows.Forms.DataVisualization.Charting.ChartImageFormat.Jpeg); break; 
                    }
                }
            }
            using (SaveFileDialog sfd = new SaveFileDialog())
            {
                sfd.Filter = "*.png|*.png;|*.jpg|*.jpg";
                sfd.AddExtension = true;
                sfd.FileName = "Сила";
                if (sfd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    switch (sfd.FilterIndex)
                    {
                        case 1: chart3.SaveImage(sfd.FileName, System.Windows.Forms.DataVisualization.Charting.ChartImageFormat.Png); break; // сохранение в формате png
                        case 2: chart3.SaveImage(sfd.FileName, System.Windows.Forms.DataVisualization.Charting.ChartImageFormat.Jpeg); break; //сохранение в формате jpeg
                    }
                }
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}

    
   

